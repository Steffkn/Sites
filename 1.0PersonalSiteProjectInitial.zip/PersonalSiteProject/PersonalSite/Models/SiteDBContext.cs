﻿using Microsoft.AspNet.Identity.EntityFramework;
using PersonalSite.Migrations;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace PersonalSite.Models
{
    public class SiteDBContext : IdentityDbContext<AppUser>
    {
        public SiteDBContext()
            : base("DefaultConnection")
        {
            Database.SetInitializer( new MigrateDatabaseToLatestVersion<SiteDBContext,Configuration>());
        }
    }
}